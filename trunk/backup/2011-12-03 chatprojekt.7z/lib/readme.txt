LionBars 0.2.1

How to use LionBars?
1. Download LionBars.
2. Include the .js file right after jQuery, like this: 

	<script type="text/javascript" src="jQuery.lionbars.0.1.1.min.js"></script>

3. Include the .css file in your main .css file, like this: 
	
	@include 'lionbars.css';

4. Call the lionbars() function on elements of your choise. For example:
	
	$('#div1').lionbars();
	
	// Options: function(color, showOnMouseOver, visibleBar, visibleBg);

5. That's all!